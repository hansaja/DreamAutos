<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Uploading a File</h2>
	<h3>Select the file to upload</h3>
<form method="POST" action="example_3php.php" enctype="multipart/form-data">
<input type="file" name="myfile">
<input type="submit" name="" size="50" value="Upload">
</form>
</body>
</html>