<html>
<head>
</head>
<body>
	<h1>Recieve Data</h1>
	<?php
	$type = $_REQUEST["type"];
	$choice1 = $_REQUEST["choice_1"];
	$choice2 = $_REQUEST["choice_2"];
	echo "Favourite $type <br>
	1.$choice1 <br>
	2.$choice2 <br>"
	?>
</body>
</html>
