<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form name="myform" method="POST" action="php.php" enctype="multipart/form-data">
	<label>File:</label>
	<input type="file" name="image">
	<input type="submit" name="">
</form>

</body>
</html>