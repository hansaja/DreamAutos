var pwd = document.getElementById("pwd");
var cnfrmpwd = document.getElementById("cnfrmpwd");
if (pwd==cnfrmpwd) 
{
	alert("Passwords Match!");
}
else
{
	alert("Passwords don't match");
}